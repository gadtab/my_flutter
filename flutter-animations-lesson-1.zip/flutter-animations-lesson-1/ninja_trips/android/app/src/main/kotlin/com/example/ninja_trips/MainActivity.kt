package com.example.ninja_trips

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
