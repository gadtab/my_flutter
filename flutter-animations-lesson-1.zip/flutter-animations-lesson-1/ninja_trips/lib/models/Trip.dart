class Trip {
  final String title;
  final String price;
  final String nights;
  final String img;

  Trip({this.title, this.price, this.nights, this.img});
}
